// Protection des données sensibles — 100 % local : le texte n'est jamais envoyé ailleurs pour être vérifié.
// 1. Pendant la frappe : une petite pastille signale les données sensibles.
// 2. À l'envoi : si des données sensibles sont présentes, l'envoi est suspendu et une alerte
//    propose de les anonymiser (remplacement par des repères neutres comme [EMAIL_1]).
(() => {
  const EDITOR_SELECTOR = '.ProseMirror[contenteditable="true"], div[contenteditable="true"]';
  const SEND_BTN = '[data-testid="chat-input-send"], button[aria-label^="Envoyer"], button[aria-label^="Send"], .rounded-composer button[type="submit"], fieldset button[type="submit"]';

  // ---------- Validations (évitent les faux positifs) ----------
  const digits = (s) => s.replace(/\D/g, '');
  function luhn(v) {
    const d = digits(v);
    if (d.length < 13 || d.length > 19 || /^(\d)\1+$/.test(d)) return false;
    let sum = 0;
    for (let i = 0; i < d.length; i++) {
      let n = +d[d.length - 1 - i];
      if (i % 2) { n *= 2; if (n > 9) n -= 9; }
      sum += n;
    }
    return sum % 10 === 0;
  }
  function ibanOk(v) {
    const s = v.replace(/\s/g, '').toUpperCase();
    if (s.length < 15 || s.length > 34) return false;
    const r = (s.slice(4) + s.slice(0, 4)).replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));
    let mod = 0;
    for (const ch of r) mod = (mod * 10 + +ch) % 97;
    return mod === 1;
  }
  function nirOk(v) {
    const s = v.replace(/\s/g, '').toUpperCase();
    if (s.length !== 15) return false;
    const body = s.slice(0, 13).replace('2A', '19').replace('2B', '18');
    if (!/^\d{13}$/.test(body)) return false;
    let mod = 0;
    for (const ch of body) mod = (mod * 10 + +ch) % 97;
    return 97 - mod === +s.slice(13);
  }

  // ---------- Règles ----------
  // sev : 3 = critique, 2 = personnelle, 1 = technique. group : partie à masquer (le reste est conservé).
  const RULES = [
    { type: 'secret', label: 'API key / token', token: 'API_KEY', sev: 3,
      re: /\b(?:sk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|xox[abprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{35}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})/g },
    { type: 'password', label: 'Password', token: 'PASSWORD', sev: 3, group: 1,
      re: /(?<![\p{L}\d])(?:mot de passe|mdp|password|passwd|pwd|code pin|code secret)(?:\s*[:=]|\s+(?:est|is)\s*:?)\s*(\S{4,})/gdiu },
    { type: 'iban', label: 'IBAN', token: 'IBAN', sev: 3, check: ibanOk,
      re: /\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){2,7}(?:\s?[A-Z0-9]{1,4})?\b/g },
    { type: 'nir', label: 'Social security no.', token: 'SSN', sev: 3, check: nirOk,
      re: /\b[12]\s?\d{2}\s?\d{2}\s?(?:\d{2}|2[AB])\s?\d{3}\s?\d{3}\s?\d{2}\b/gi },
    { type: 'card', label: 'Bank card', token: 'CARD', sev: 3, check: luhn,
      re: /(?<![\d-])\d(?:[ -]?\d){12,18}(?![\d-])/g },
    { type: 'email', label: 'Email', token: 'EMAIL', sev: 2,
      re: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g },
    { type: 'phone', label: 'Phone', token: 'PHONE', sev: 2,
      re: /(?<![\d+])(?:(?:\+|00)33[\s.-]?[1-9](?:[\s.-]?\d{2}){4}|0[1-9](?:[\s.-]?\d{2}){4}|\+\d{1,3}[\s.-]?\(?\d{1,4}\)?(?:[\s.-]?\d{2,4}){2,4})(?!\d)/g },
    { type: 'birth', label: 'Date of birth', token: 'BIRTH_DATE', sev: 2, group: 1,
      re: /\b(?:né|née|naissance|ddn|date de naissance|born|dob)\s*(?:le|:|on)?\s*(\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4})/gdi },
    { type: 'person', label: 'Person name', token: 'PERSON', sev: 2, group: 1,
      re: /\b(?:M\.|Mme|Mlle|Mr\.?|Mrs\.?|Ms\.?|Dr\.?|Docteur|Pr\.?|Professeur|Monsieur|Madame|patiente?|Patiente?)\s+((?:[A-ZÀ-Ý][a-zà-ÿ'’-]+|[A-ZÀ-Ý]{2,})(?:\s+(?:[A-ZÀ-Ý][a-zà-ÿ'’-]+|[A-ZÀ-Ý]{2,}))?)/gd },
    { type: 'person', label: 'Person name', token: 'PERSON', sev: 2, group: 1,
      re: /(?:[Jj]e m['’]appelle|[Jj]e me nomme|[Mm]on nom (?:est|c['’]est)|[Mm]y name is|[Nn]om(?: complet| de famille)?\s*:|[Pp]rénom\s*:|[Nn]ame\s*:|[Cc]lient(?:e)?\s*:)\s*([\p{L}][\p{L}'’-]+(?:\s+\p{Lu}[\p{L}'’-]+){0,2})/gdu },
    { type: 'person', label: 'Person name', token: 'PERSON', sev: 2,
      re: /(?<![\p{L}])\p{Lu}[\p{Ll}'’-]+\s+\p{Lu}{3,}(?:[-\s]\p{Lu}{2,})?(?![\p{L}])/gu },
    { type: 'address', label: 'Postal address', token: 'ADDRESS', sev: 2,
      re: /\b\d{1,4}(?:\s?(?:bis|ter))?,?\s+(?:rue|avenue|av\.|boulevard|bd|allée|chemin|impasse|place|route|quai|cours|square)\s+[^\n,;]{2,40}(?:,?\s*\d{5}\s+[A-ZÀ-Ý][^\n,;]{1,30})?/gi },
    { type: 'amount', label: 'Budget / price', token: 'AMOUNT', sev: 2,
      re: /(?:[€$£]\s?\d(?:[.,   ]?\d)*(?:\s?(?:k|K|M|Md|millions?|milliards?|mille|bn|m)\b)?|(?<![\w.])\d(?:[.,   ]?\d)*\s?(?:k|K|M|Md|millions?|milliards?|mille|bn)?\s?(?:€|\$|£|euros?|EUR|USD|GBP|dollars?|HT|TTC|k€|M€)(?![\p{L}]))/gu },
    { type: 'amount', label: 'Budget / price', token: 'AMOUNT', sev: 2, group: 1,
      re: /(?<![\p{L}])(?:budget|prix|tarif|co[uû]t|montant|devis|facture|salaire|r[ée]mun[ée]ration|CA|chiffre d['’]affaires|price|cost|salary|revenue|quote|invoice|fee)s?\b[^\n\d]{0,25}?(\d(?:[.,   ]?\d)*(?:\s?(?:k|K|M|Md|millions?|milliards?|mille|bn)\b)?)/gdu },
    { type: 'ip', label: 'IP address', token: 'IP', sev: 1,
      re: /(?<!(?:version|v|ver)\s?)(?<![\d.])(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?![\d.])/gi }
  ];

  function detect(text) {
    const found = [];
    RULES.forEach((rule, prio) => {
      rule.re.lastIndex = 0;
      for (const m of text.matchAll(rule.re)) {
        let value = m[0], start = m.index;
        if (rule.group) {
          value = m[rule.group];
          if (!value || !m.indices?.[rule.group]) continue;
          start = m.indices[rule.group][0];
        }
        if (rule.check && !rule.check(value)) continue;
        found.push({ start, end: start + value.length, value, rule, prio });
      }
    });
    // une seule détection par portion de texte : la plus grave (puis la plus longue) l'emporte
    found.sort((a, b) => b.rule.sev - a.rule.sev || a.prio - b.prio || (b.end - b.start) - (a.end - a.start));
    const kept = [];
    for (const f of found) if (!kept.some((k) => f.start < k.end && k.start < f.end)) kept.push(f);
    return kept.sort((a, b) => a.start - b.start);
  }

  function anonymize(text) {
    const found = detect(text);
    const counters = {}, tokens = new Map(), items = [];
    let out = '', pos = 0;
    for (const f of found) {
      const key = f.rule.token + '|' + f.value.replace(/\s/g, '').toLowerCase();
      let tok = tokens.get(key);
      if (!tok) {
        counters[f.rule.token] = (counters[f.rule.token] || 0) + 1;
        tok = `[${f.rule.token}_${counters[f.rule.token]}]`;
        tokens.set(key, tok);
        items.push({ type: f.rule.type, label: f.rule.label, sev: f.rule.sev, value: f.value, token: tok });
      }
      out += text.slice(pos, f.start) + tok;
      pos = f.end;
    }
    return { text: out + text.slice(pos), items, count: found.length };
  }

  // ---------- Zone de saisie ----------
  let activeEditor = null;
  const getEditor = () => (activeEditor?.isConnected && activeEditor) ||
    document.querySelector('[data-testid="chat-input"]') ||
    document.querySelector('.rounded-composer .ProseMirror') ||
    document.querySelector(EDITOR_SELECTOR);
  // texte bloc par bloc (un paragraphe = une ligne), fidèle pour le remplacement
  function getText() {
    const ed = getEditor();
    if (!ed) return '';
    const blocks = [...ed.children];
    const raw = blocks.length && blocks.every((b) => /^(P|DIV|H\d|PRE|BLOCKQUOTE|UL|OL)$/.test(b.tagName))
      ? blocks.map((b) => b.innerText.replace(/\n$/, '')).join('\n')
      : ed.innerText;
    return raw.replace(/ /g, ' ').trim();
  }

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (t) => t.replace(/\s+/g, ' ').trim();
  // L'éditeur de Claude (ProseMirror) ne prend en compte une nouvelle sélection qu'au tour suivant :
  // on sélectionne, on attend qu'il l'ait enregistrée, puis on remplace — et on vérifie le résultat.
  async function selectAll(ed) {
    ed.focus();
    document.execCommand('selectAll');
    const sel = window.getSelection();
    if (!sel.rangeCount || !ed.contains(sel.anchorNode)) {
      const range = document.createRange();
      range.selectNodeContents(ed);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    document.dispatchEvent(new Event('selectionchange'));
    await wait(80);
  }
  // Remplacement ciblé : chaque donnée est sélectionnée dans le DOM puis remplacée par son repère
  async function replaceInPlace(ed, tokenOf) {
    for (let pass = 0; pass < 2; pass++) {
      const nodes = [], walker = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
      let flat = '';
      for (let n; (n = walker.nextNode());) { nodes.push({ n, at: flat.length }); flat += n.data; }
      const hits = detect(flat.replace(/\u00a0/g, ' '));
      if (!hits.length) return true;
      const locate = (i) => { let k = nodes.length - 1; while (k > 0 && nodes[k].at > i) k--; return nodes[k]; };
      const ranges = hits.map((h) => {
        const s = locate(h.start), e = locate(h.end - 1), r = document.createRange();
        r.setStart(s.n, h.start - s.at); r.setEnd(e.n, h.end - e.at);
        return { r, tok: tokenOf(h) };
      });
      ed.focus();
      for (const { r, tok } of ranges.reverse()) {
        const sel = window.getSelection();
        sel.removeAllRanges(); sel.addRange(r);
        document.dispatchEvent(new Event('selectionchange'));
        await wait(40);
        document.execCommand('insertText', false, tok);
        await wait(40);
      }
      await wait(120);
    }
    return !detect(getText()).length;
  }
  async function setText(text, tokenOf) {
    const ed = getEditor();
    if (!ed) return false;
    if (tokenOf && await replaceInPlace(ed, tokenOf).catch(() => false)) return true;
    const done = () => norm(getText()) === norm(text) || !detect(getText()).length;
    // 1. collage simulé (paragraphes conservés)
    await selectAll(ed);
    const dt = new DataTransfer();
    dt.setData('text/plain', text);
    ed.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    await wait(120);
    if (done()) return true;
    // 2. saisie directe sur tout le contenu
    await selectAll(ed);
    document.execCommand('insertText', false, text);
    await wait(120);
    if (done()) return true;
    // 3. on vide, puis on saisit
    await selectAll(ed);
    document.execCommand('delete');
    await wait(60);
    document.execCommand('insertText', false, text);
    await wait(120);
    return done();
  }

  // ---------- Interface ----------
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mask = (v) => {
    const s = v.trim();
    if (s.length <= 6) return '•'.repeat(s.length);
    return s.slice(0, 3) + '•'.repeat(Math.min(6, s.length - 5)) + s.slice(-2);
  };
  const ICON = {
    lock: '<svg viewBox="0 0 24 24"><rect x="5" y="10.5" width="14" height="9.5" rx="2.5"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/></svg>',
    shield: '<svg viewBox="0 0 24 24"><path d="M12 3.5 19 6v5.5c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6z"/><path d="m9 12 2.2 2.2L15.5 10"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    x: '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg>',
    arrow: '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    send: '<svg viewBox="0 0 24 24"><path d="M12 19V5M6 11l6-6 6 6"/></svg>'
  };
  const summary = (items) => {
    const byLabel = {};
    items.forEach((i) => { byLabel[i.label] = (byLabel[i.label] || 0) + 1; });
    return Object.entries(byLabel).map(([l, n]) => (n > 1 ? `${n} × ${l.toLowerCase()}` : l.toLowerCase())).join(', ');
  };

  function placeAbove(el, gap = 8) {
    const composer = document.querySelector('.rounded-composer') || getEditor();
    const r = composer?.getBoundingClientRect();
    if (!r?.width) return;
    el.style.left = `${r.left}px`;
    el.style.width = `${r.width}px`;
    el.style.bottom = `${window.innerHeight - r.top + gap}px`;
  }

  // Pastille discrète pendant la frappe
  let pill, pillIgnored = '';
  function ensurePill() {
    if (pill?.isConnected) return;
    pill = document.createElement('div');
    pill.className = 'psp';
    pill.setAttribute('role', 'status');
    pill.addEventListener('click', (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'anon') doAnonymize();
      if (a === 'close') { pillIgnored = signature(detect(getText())); hidePill(); }
    });
    document.body.appendChild(pill);
  }
  const signature = (found) => found.map((f) => f.value).join('|');
  function showPill(found) {
    if (signature(found) === pillIgnored) return hidePill();
    ensurePill();
    const { items } = anonymize(getText());
    const crit = items.some((i) => i.sev === 3);
    pill.dataset.level = crit ? 'high' : 'mid';
    pill.innerHTML = `
      <span class="psp-ic">${ICON.lock}</span>
      <span class="psp-text"><b>${items.length} sensitive item${items.length > 1 ? 's' : ''}</b><span class="psp-why"> · ${esc(summary(items))}</span></span>
      <button type="button" class="psp-btn" data-a="anon">Anonymize</button>
      <button type="button" class="psp-x" data-a="close" aria-label="Dismiss">${ICON.x}</button>`;
    placeAbove(pill);
    pill.classList.add('psp-on');
  }
  function hidePill() { pill?.classList.remove('psp-on'); }

  // Alerte à l'envoi
  let card, cardTimer;
  function ensureCard() {
    if (card?.isConnected) return;
    card = document.createElement('div');
    card.className = 'pss';
    card.setAttribute('role', 'alertdialog');
    card.setAttribute('aria-label', 'Sensitive data detected');
    card.addEventListener('click', (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'anon') doAnonymize(true);
      if (a === 'force') { allowOnce = getText(); closeCard(); reallySend(); }
      if (a === 'send') { closeCard(); reallySend(); }
      if (a === 'close') closeCard();
      if (a === 'copy') navigator.clipboard.writeText(card._clean || '').then(() => {
        const b = card.querySelector('[data-a="copy"]'); if (b) b.textContent = 'Copied ✓';
      });
    });
    document.body.appendChild(card);
  }
  function openCard() {
    ensureCard();
    clearTimeout(cardTimer);
    const { items } = anonymize(getText());
    const crit = items.some((i) => i.sev === 3);
    const rows = items.slice(0, 6).map((i) => `
      <li class="pss-row">
        <span class="pss-type" data-sev="${i.sev}">${esc(i.label)}</span>
        <span class="pss-val">${esc(mask(i.value))}</span>
        <span class="pss-arrow">${ICON.arrow}</span>
        <code class="pss-tok">${esc(i.token)}</code>
      </li>`).join('');
    const more = items.length > 6 ? `<li class="pss-more">+ ${items.length - 6} more</li>` : '';
    card.dataset.state = 'alert';
    card.dataset.level = crit ? 'high' : 'mid';
    card.innerHTML = `
      <div class="pss-head">
        <span class="pss-ic">${ICON.lock}</span>
        <div class="pss-titles">
          <div class="pss-title">Sensitive data detected</div>
          <div class="pss-sub">${crit ? 'This information should not be shared with an AI.' : 'Better not to share this personal information.'} Anonymizing replaces it with neutral placeholders.</div>
        </div>
        <button type="button" class="pss-x" data-a="close" aria-label="Close">${ICON.x}</button>
      </div>
      <ul class="pss-list">${rows}${more}</ul>
      <div class="pss-actions">
        <span class="pss-local">${ICON.shield}100% local check</span>
        <button type="button" class="pss-btn pss-btn--ghost" data-a="force">Send anyway</button>
        <button type="button" class="pss-btn pss-btn--primary" data-a="anon">${ICON.shield}Anonymize</button>
      </div>`;
    hidePill();
    placeAbove(card, 12);
    requestAnimationFrame(() => card.classList.add('pss-on'));
    follow();
  }
  function cardDone(n) {
    clearTimeout(cardTimer);
    card.dataset.state = 'done';
    card.innerHTML = `
      <div class="pss-head">
        <span class="pss-ic pss-ic--ok">${ICON.check}</span>
        <div class="pss-titles">
          <div class="pss-title">${n} item${n > 1 ? 's' : ''} anonymized</div>
          <div class="pss-sub">Placeholders like <code>[EMAIL_1]</code> now replace the original information. Review your message, then send it.</div>
        </div>
        <button type="button" class="pss-x" data-a="close" aria-label="Close">${ICON.x}</button>
      </div>
      <div class="pss-actions">
        <span class="pss-local">${ICON.shield}Safe to send</span>
        <button type="button" class="pss-btn pss-btn--ghost" data-a="close">Edit first</button>
        <button type="button" class="pss-btn pss-btn--primary" data-a="send">${ICON.send}Send</button>
      </div>`;
    if (!card.classList.contains('pss-on')) { placeAbove(card, 12); card.classList.add('pss-on'); follow(); }
  }
  function closeCard() { card?.classList.remove('pss-on'); clearTimeout(cardTimer); }
  const follow = () => {
    if (!card?.classList.contains('pss-on') && !pill?.classList.contains('psp-on')) return;
    if (card?.classList.contains('pss-on')) placeAbove(card, 12);
    if (pill?.classList.contains('psp-on')) placeAbove(pill);
    requestAnimationFrame(follow);
  };

  let anonymizing = false;
  async function doAnonymize(fromCard = false) {
    if (anonymizing) return;
    const before = anonymize(getText());
    if (!before.count) { hidePill(); closeCard(); return; }
    anonymizing = true;
    const tokenOf = (h) => before.items.find((i) => i.value.replace(/\s/g, '').toLowerCase() === h.value.replace(/\s/g, '').toLowerCase() && i.type === h.rule.type)?.token || `[${h.rule.token}]`;
    const ok = await setText(before.text, tokenOf).catch(() => false);
    anonymizing = false;
    hidePill();
    if (ok) {
      closeCard();          // anonymisé : on s'efface, sans message
    } else {
      // échec : on propose de copier la version anonymisée pour la coller soi-même
      showCopyFallback(before.text);
    }
  }
  function showCopyFallback(clean) {
    if (!card?.classList.contains('pss-on')) openCard();
    card.dataset.state = 'done';
    card.innerHTML = `
      <div class="pss-head">
        <span class="pss-ic">${ICON.lock}</span>
        <div class="pss-titles">
          <div class="pss-title">Automatic replacement failed</div>
          <div class="pss-sub">The anonymized version is ready: copy it and paste it over your text (⌘A then ⌘V).</div>
        </div>
        <button type="button" class="pss-btn pss-btn--primary" data-a="copy">Copy anonymized version</button>
        <button type="button" class="pss-x" data-a="close" aria-label="Close">${ICON.x}</button>
      </div>`;
    card._clean = clean;
  }

  // ---------- Garde à l'envoi ----------
  let bypass = false, allowOnce = null;
  function reallySend() {
    const btn = document.querySelector(SEND_BTN);
    if (!btn) return;
    bypass = true;
    btn.click();
    bypass = false;
  }
  const block = (e) => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
  const mustStop = () => {
    if (bypass) return false;
    const text = getText();
    if (allowOnce && allowOnce === text) return false;
    return detect(text).length > 0;
  };

  // enregistrés avant ceux du conseiller (content.js) : un envoi bloqué n'est pas analysé
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && card?.classList.contains('pss-on')) { closeCard(); return; }
    if (e.key === 'Enter' && !e.shiftKey && card?.classList.contains('pss-on') && card.dataset.state === 'done' && !mustStop()) { closeCard(); return; }
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
    const ed = e.target?.closest?.(EDITOR_SELECTOR);
    if (!ed) return;
    activeEditor = ed;
    if (mustStop()) { block(e); openCard(); }
  }, true);
  window.addEventListener('pointerdown', (e) => {
    if (!e.target?.closest?.(SEND_BTN) || !mustStop()) return;
    block(e); openCard();
  }, true);
  ['mousedown', 'pointerup', 'mouseup', 'click', 'touchstart', 'touchend'].forEach((t) =>
    window.addEventListener(t, (e) => { if (e.target?.closest?.(SEND_BTN) && mustStop()) block(e); }, true));

  // ---------- Surveillance pendant la frappe ----------
  let typingTimer;
  function scan() {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
      const found = detect(getText());
      if (found.length) { showPill(found); follow(); } else { hidePill(); pillIgnored = ''; }
      if (card?.classList.contains('pss-on') && card.dataset.state === 'alert' && !found.length) closeCard();
    }, 250);
  }
  // frappe, collage, glisser-déposer, dictée : tout changement du texte relance l'analyse
  ['input', 'paste', 'drop', 'keyup'].forEach((t) => document.addEventListener(t, (e) => {
    const ed = e.target?.closest?.(EDITOR_SELECTOR);
    if (!ed || anonymizing) return;
    activeEditor = ed;
    if (t !== 'keyup') allowOnce = null;
    scan();
  }, true));
  let lastSeen = '';
  setInterval(() => {
    if (anonymizing) return;
    const t = getText();
    if (t !== lastSeen) { lastSeen = t; allowOnce = allowOnce === t ? allowOnce : null; scan(); }
  }, 800);
  window.addEventListener('resize', () => { if (pill) placeAbove(pill); if (card) placeAbove(card, 12); });

  // API utilisée par le conseiller : jamais de donnée sensible envoyée à OpenAI
  globalThis.PSPrivacy = {
    detect, anonymize,
    busy: () => !!(pill?.classList.contains('psp-on') || card?.classList.contains('pss-on'))
  };
})();
