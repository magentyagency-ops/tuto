// Clé API OpenAI (ne partage pas ce fichier)
self.OPENAI_API_KEY = "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";
self.OPENAI_MODEL = "gpt-5.4-nano";
// Usage insights dashboard (PerfectServe-Insights, hosted on Vercel). Must match PS_INGEST_TOKEN on the server.
self.INSIGHTS_URL = "https://perfectserve-insights.vercel.app/api/ingest";
self.INSIGHTS_TOKEN = "8ifzp9btzyNmrFbtbd7UuLnnYgG2CHHA";
