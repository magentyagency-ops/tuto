// The OpenAI key now lives on the PerfectServe server (Vercel env OPENAI_API_KEY), never in the extension.
// Usage insights dashboard (PerfectServe-Insights, hosted on Vercel). Must match PS_INGEST_TOKEN on the server.
self.INSIGHTS_URL = "https://perfectserve-insights.vercel.app/api/ingest";
self.INSIGHTS_TOKEN = "8ifzp9btzyNmrFbtbd7UuLnnYgG2CHHA";
