// Cost of each exchange, shown discreetly under Claude's reply.
// Only real billed amounts (measured by realcost.js on the Enterprise usage meter): no estimate,
// because the text alone misses most of the cost (system prompt, context, thinking, tools).
(() => {
  const money = (v) => '$' + (Math.abs(v * 100 - Math.round(v * 100)) < 1e-6 ? v.toFixed(2) : v.toFixed(3));

  function show(host, real) {
    const sig = real ? `real|${real.v}` : 'measuring';
    let el = host.querySelector(':scope > .psc');
    if (el?.dataset.sig === sig) return;
    if (!el) { el = document.createElement('div'); host.appendChild(el); }
    el.dataset.sig = sig;
    el.className = 'psc psc--out psc--real';
    if (!real) {
      el.textContent = 'measuring cost…';
      el.title = 'Waiting for your Enterprise usage meter to update';
    } else if (!real.v) {
      el.textContent = '< $0.01';
      el.title = 'Billed cost of this exchange: the usage meter moved by less than one cent';
    } else {
      el.textContent = money(real.v);
      el.title = 'Billed cost of this exchange (your message + the reply, including context, thinking and tools) · from your PerfectServe Enterprise usage';
    }
  }

  function scan() {
    const R = globalThis.PSRealCost;
    if (!R) return;
    document.querySelectorAll('[data-testid="assistant-message"]').forEach((msg) => {
      const host = msg.closest('[role="article"]') || msg;
      const key = msg.dataset.turnKey, real = R.get(key);
      if (real || R.pending(key)) show(host, real);
    });
  }

  const start = () => setInterval(() => { try { scan(); } catch {} }, 1000);
  if (document.readyState === 'complete') setTimeout(start, 1200);
  else window.addEventListener('load', () => setTimeout(start, 1200));
})();
