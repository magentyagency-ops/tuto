// Coût estimé de chaque message (envoyé et reçu), affiché discrètement sous la bulle.
// Estimation au tarif API officiel du modèle choisi (~4 caractères par token).
(() => {
  // Tarifs officiels API Anthropic, $ par million de tokens [entrée, sortie]
  // Source : platform.claude.com/docs/en/about-claude/pricing (relevé le 2026-10-02)
  const PRICES = {
    'fable 5.1': [10, 50], 'fable 5': [10, 50], 'mythos 5.1': [10, 50], 'mythos 5': [10, 50],
    'opus 5.5': [4, 20], 'opus 5': [5, 25], 'opus 4.8': [5, 25], 'opus 4.7': [5, 25], 'opus 4.6': [5, 25], 'opus 4.5': [5, 25],
    'opus 4.1': [15, 75], 'opus 4': [15, 75],
    'sonnet 5.5': [2, 10], 'sonnet 5': [2, 10], 'sonnet 4.6': [3, 15], 'sonnet 4.5': [3, 15], 'sonnet 4': [3, 15],
    'haiku 4.5': [1, 5], 'haiku 3.5': [0.8, 4]
  };
  // à défaut de version lisible : modèle le plus récent de la famille
  const LATEST = { fable: 'fable 5.1', mythos: 'mythos 5.1', opus: 'opus 5.5', sonnet: 'sonnet 5.5', haiku: 'haiku 4.5' };
  // Claude 4.7 et suivants : nouveau tokenizer, ~30 % de tokens en plus pour un même texte
  const OLD_TOKENIZER = /^(opus 4(\.[0-6])?|sonnet 4(\.[56])?|haiku)( |$)/;
  const tokens = (t, key) => Math.max(1, Math.round(t.length / 4 * (OLD_TOKENIZER.test(key) ? 1 : 1.3)));
  const money = (v) => v >= 0.01 ? `$${v.toFixed(3)}` : `$${Number(v.toPrecision(2)).toFixed(Math.min(8, 1 - Math.floor(Math.log10(v))))}`;

  function model() {
    const btn = document.querySelector('[data-testid="model-selector-dropdown"]');
    const label = `${btn?.getAttribute('aria-label') || ''} ${btn?.textContent || ''}`.toLowerCase();
    const m = label.match(/(fable|mythos|opus|sonnet|haiku)\s*(\d+(?:\.\d+)?)?/);
    const fam = m?.[1] || 'sonnet';
    const exact = m?.[2] && `${fam} ${m[2]}`;
    const key = exact && PRICES[exact] ? exact : LATEST[fam];
    return { key, name: key.replace(/\b\w/g, (c) => c.toUpperCase()) };
  }

  function badge(host, text, kind) {
    const m = host.dataset.psModel ? JSON.parse(host.dataset.psModel) : model();
    const n = tokens(text, m.key);
    host.dataset.psModel = JSON.stringify(m);   // le modèle est figé au moment du message
    const price = PRICES[m.key][kind === 'in' ? 0 : 1] * n / 1e6;
    const sig = `${n}|${m.key}`;
    let el = host.querySelector(':scope > .psc');
    if (el?.dataset.sig === sig) return;
    if (!el) { el = document.createElement('div'); el.className = `psc psc--${kind}`; host.appendChild(el); }
    el.dataset.sig = sig;
    el.title = `Estimated API cost · Claude ${m.name} · $${PRICES[m.key][kind === 'in' ? 0 : 1]}/M ${kind === 'in' ? 'input' : 'output'} tokens`;
    el.textContent = money(price);
  }

  function scan() {
    document.querySelectorAll('[data-testid="user-message"]').forEach((msg) => {
      const host = msg.closest('[role="article"]') || msg.parentElement;
      if (host) badge(host, msg.innerText.trim(), 'in');
    });
    document.querySelectorAll('[data-testid="assistant-message"][data-is-streaming="false"]').forEach((msg) => {
      const body = msg.querySelector('.font-claude-response') || msg;
      const host = msg.closest('[role="article"]') || msg;
      badge(host, body.innerText.trim(), 'out');
    });
  }

  const start = () => setInterval(() => { try { scan(); } catch {} }, 1500);
  if (document.readyState === 'complete') setTimeout(start, 1200);
  else window.addEventListener('load', () => setTimeout(start, 1200));
})();
