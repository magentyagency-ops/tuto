// Thème PerfectServe pour claude.ai (design system « cds », data-color-version v2).
// Les couleurs passent par les tokens --cds-* ; le reste est dans theme.css.
(() => {
  const B = {
    plum: '#681338', plum2: '#7d1d47', plumDeep: '#520f2c',
    evergreen: '#005a50', evergreen2: '#0a6e62',
    ink: '#101b15', linen: '#f6f2ee', paper: '#f9f9f9',
    orchid: '#f6b7fa', sprout: '#b3f297'
  };

  // ---------- Échelle de gris de Claude, teintée linen (clairs) → ink (foncés) ----------
  const GRAYS = {
    0: '#ffffff', 10: '#fcfcfb', 20: '#f9f9f7', 30: '#f6f6f4', 40: '#f3f3f0', 50: '#f0efec', 60: '#edece8',
    70: '#eae9e4', 80: '#e7e6e1', 90: '#e4e3dd', 100: '#e1e0d9', 150: '#d2d1c7', 200: '#c3c2b7', 250: '#b4b3a8',
    300: '#a5a49a', 350: '#97958d', 400: '#898781', 450: '#7b7974', 500: '#6d6b67', 550: '#5f5e5a', 600: '#52514e',
    650: '#454442', 700: '#383835', 750: '#2c2c2a', 800: '#20201f', 810: '#1e1e1d', 820: '#1c1c1b', 830: '#1a1a19',
    840: '#181817', 850: '#151515', 860: '#131313', 870: '#111111', 880: '#0f0f0f', 890: '#0d0d0d', 900: '#0b0b0b'
  };
  const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const hex = (a) => '#' + a.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => hex(rgb(a).map((v, i) => v + (rgb(b)[i] - v) * t));
  const grayVars = Object.entries(GRAYS).flatMap(([k, h]) => {
    const n = +k;
    // clairs → linen, moyens → légère teinte ink (même luminosité), très foncés → ink
    const v = n === 0 ? '#ffffff' : n < 200 ? mix(h, B.linen, 0.35) : n < 500 ? mix(h, B.linen, 0.1) : n < 800 ? mix(h, '#3c4a42', 0.22) : mix(h, B.ink, 0.6);
    return [[`--cds-gray-${k}`, v], [`--cds-neutral-${k}`, v]];
  });

  const ROLE_ACCENT_LIGHT = {
    50: '#fcf2f6', 100: '#f9e6ef', 250: '#e7a9c4', 300: '#d77ea6', 400: '#8e2a55', 450: B.plum,
    600: B.plumDeep, 700: '#3d0b21', 800: '#290716', 850: '#1a040e'
  };

  const LIGHT = {
    // Surfaces & textes
    '--cds-surface-0': B.linen, '--cds-surface-1': B.paper, '--cds-page-bg': B.paper,
    '--cds-surface-2': '#ffffff', '--cds-surface-3': '#ffffff', '--cds-surface-panel': '#ffffff', '--cds-surface-popover': '#ffffff',
    '--cds-text-primary': B.ink, '--cds-text-secondary': '#3b4741', '--cds-text-muted': '#6b756f', '--cds-text-accent': B.plum,
    '--cds-text-success': B.evergreen, '--cds-text-pro': B.evergreen,
    // Remplissages : primaire, marque et accent = plum
    '--cds-fill-primary': B.plum, '--cds-fill-primary-hover': B.plum2, '--cds-on-primary': B.paper,
    '--cds-fill-brand': B.plum, '--cds-fill-brand-hover': B.plum2, '--cds-on-brand': B.paper,
    '--cds-fill-accent': B.plum, '--cds-fill-accent-hover': B.plum2, '--cds-on-accent': B.paper,
    '--cds-bg-accent': '#f9e6ef', '--cds-bg-accent-chip': '#f9e6ef', '--cds-bg-accent-muted': 'rgba(104, 19, 56, .08)',
    '--cds-border-accent': '#e7a9c4', '--cds-radio-group-card-selected': '#fcf2f6',
    '--cds-clay': B.plum, '--cds-clay-emphasized': B.plumDeep, '--fill-brand': B.plum, '--fill-primary': B.plum,
    // Succès / Pro = evergreen + sprout
    '--cds-fill-success': B.evergreen, '--cds-fill-success-hover': B.evergreen2, '--cds-on-success': B.paper,
    '--cds-bg-success': '#e3f6da', '--cds-bg-success-chip': '#e3f6da', '--cds-border-success': B.sprout, '--fill-success': B.evergreen,
    '--cds-fill-pro': B.evergreen, '--cds-fill-pro-hover': B.evergreen2, '--cds-on-pro': B.paper,
    '--cds-bg-pro': '#dff0ec', '--cds-bg-pro-chip': '#dff0ec', '--cds-border-pro': '#8fc9bd',
    // Messages, focus, rayons
    '--cds-bg-user-message': B.plum,
    '--cds-focus-shadow': `inset 0 0 0 1px #fff, 0 0 0 1px ${B.plum}, 0 0 0 4px rgba(246, 183, 250, .55)`,
    '--cds-shadow-drop-ring': `inset 0 0 0 2px ${B.plum}`,
    '--cds-shadow-drop-glow': 'inset 0 0 24px -2px rgba(104, 19, 56, .2)',
    '--cds-tooltip-bg': B.ink, '--cds-role-tooltip-bg': B.ink,
    '--cds-radius': '.625rem', '--cds-radius--lg': '.9375rem', '--cds-radius--sm': '.5rem', '--cds-radius--xs': '.375rem',
    '--cds-radius-composer': '1.25rem',
    // Anciennes variables encore utilisées par certains composants
    '--fill-warning': '#e8b04a'
  };
  Object.entries(ROLE_ACCENT_LIGHT).forEach(([k, v]) => { LIGHT[`--cds-role-accent-${k}`] = v; });
  Object.assign(LIGHT, { '--cds-role-accent-fill': B.plum, '--cds-role-accent-fill-hover': B.plum2, '--cds-role-accent-on': B.paper });

  const DARK = {
    '--cds-surface-0': '#0b140f', '--cds-surface-1': B.ink, '--cds-page-bg': B.ink,
    '--cds-surface-2': '#16241c', '--cds-surface-3': '#1b2a22', '--cds-surface-panel': '#1b2a22', '--cds-surface-popover': '#1b2a22',
    '--cds-text-primary': B.paper, '--cds-text-secondary': '#d6d3ce', '--cds-text-muted': '#9b9a96', '--cds-text-accent': B.orchid,
    '--cds-text-success': B.sprout, '--cds-text-pro': B.sprout,
    '--cds-fill-primary': B.orchid, '--cds-fill-primary-hover': '#f8d5fa', '--cds-on-primary': B.plum,
    '--cds-fill-brand': B.orchid, '--cds-fill-brand-hover': '#f8d5fa', '--cds-on-brand': B.plum,
    '--cds-fill-accent': B.orchid, '--cds-fill-accent-hover': '#f8d5fa', '--cds-on-accent': B.plum,
    '--cds-bg-accent': 'rgba(246, 183, 250, .16)', '--cds-bg-accent-chip': 'rgba(246, 183, 250, .16)',
    '--cds-bg-accent-muted': 'rgba(246, 183, 250, .1)', '--cds-border-accent': 'rgba(246, 183, 250, .45)',
    '--cds-clay': B.orchid, '--cds-clay-emphasized': B.orchid, '--fill-brand': B.orchid, '--fill-primary': B.orchid,
    '--cds-fill-success': B.sprout, '--cds-on-success': B.ink, '--cds-bg-success': 'rgba(179, 242, 151, .14)', '--cds-border-success': 'rgba(179, 242, 151, .45)',
    '--cds-fill-pro': B.sprout, '--cds-on-pro': B.ink, '--cds-bg-pro': 'rgba(179, 242, 151, .12)',
    '--cds-bg-user-message': B.plum,
    '--cds-focus-shadow': `inset 0 0 0 1px ${B.ink}, 0 0 0 1px ${B.orchid}, 0 0 0 4px rgba(246, 183, 250, .25)`,
    '--cds-role-accent-fill': B.orchid, '--cds-role-accent-fill-hover': '#f8d5fa', '--cds-role-accent-on': B.plum,
    '--cds-role-accent-450': B.orchid, '--cds-role-accent-400': '#f8c8fb', '--cds-role-accent-600': '#e9a2ee'
  };

  const SANS = '"PS Inter", Inter, system-ui, -apple-system, "Segoe UI", Arial, sans-serif';
  const HEAD = '"PS Inter Tight", "PS Inter", Inter, system-ui, Arial, sans-serif';
  const DISPLAY = '"PS Radley", Radley, Georgia, serif';
  const FONTS = {
    '--cds-font-sans': SANS, '--font-anthropic-sans': SANS, '--default-font-family': SANS, '--font-sans': SANS,
    '--font-sans-serif': SANS, '--font-ui': SANS, '--font-user-message': SANS,
    '--font-claude-response': SANS, '--font-claude-message': SANS,
    '--cds-font-sans-display': HEAD, '--font-sans-display': HEAD,
    '--font-anthropic-serif': DISPLAY, '--font-serif': DISPLAY, '--font-ui-serif': DISPLAY, '--font-display': DISPLAY,
    '--cds-font-voice': DISPLAY, '--font-voice': DISPLAY
  };

  // Variables historiques (format triplet HSL) encore lues par quelques classes utilitaires
  const toHsl = (h) => {
    let [r, g, b] = rgb(h).map((v) => v / 255);
    const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
    let hh = 0, s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      hh = (max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4) * 60;
    }
    return `${hh.toFixed(1)} ${(s * 100).toFixed(1)}% ${(l * 100).toFixed(1)}%`;
  };
  const LEGACY_LIGHT = {
    '--bg-000': '#ffffff', '--bg-100': B.paper, '--bg-200': B.linen, '--bg-300': '#ede7e1', '--bg-400': '#e3dbd3', '--bg-500': '#d4cac0',
    '--text-000': B.ink, '--text-100': B.ink, '--text-200': '#2c3832', '--text-300': '#4d5852', '--text-400': '#6e7872', '--text-500': '#8f9893',
    '--accent-brand': B.plum, '--accent-main-000': B.plumDeep, '--accent-main-100': B.plum, '--accent-main-200': B.plum2,
    '--brand-000': B.plum, '--brand-100': B.plum, '--brand-200': B.plum2, '--_brand-clay': B.plum, '--_brand-clay-emphasized': B.plumDeep,
    '--accent-000': B.plumDeep, '--accent-100': B.plum, '--accent-200': B.plum, '--accent-900': '#f9e6ef'
  };
  const LEGACY_DARK = {
    '--bg-000': '#1b2a22', '--bg-100': B.ink, '--bg-200': '#0b140f', '--bg-300': '#22332a', '--bg-400': '#2b3d33', '--bg-500': '#36493e',
    '--text-000': B.paper, '--text-100': B.linen, '--text-200': '#dcd8d3', '--text-300': '#bdbab6', '--text-400': '#9d9b98', '--text-500': '#7f7e7c',
    '--accent-brand': B.orchid, '--brand-000': B.orchid, '--brand-100': B.orchid, '--brand-200': B.orchid
  };

  const block = (pairs) => pairs.map(([k, v]) => `${k}: ${v} !important;`).join('\n');
  const legacy = (m) => Object.entries(m).map(([k, v]) => [k, toHsl(v)]);

  const DARK_SEL = [
    'html[data-mode="dark"]', 'html[data-mode="dark"] .cds-root', '.cds-root[data-mode="dark"]', '.cds-dark-scope[data-mode="dark"]'
  ].join(',\n');
  const SYSTEM_SEL = 'html[data-mode="system"], html[data-mode="system"] .cds-root, .cds-root[data-mode="system"]';

  const css = `
html:root {
${block(grayVars)}
${block(Object.entries(LIGHT))}
${block(Object.entries(FONTS))}
${block(legacy(LEGACY_LIGHT))}
}
${DARK_SEL} {
${block(Object.entries(DARK))}
${block(legacy(LEGACY_DARK))}
}
@media (prefers-color-scheme: dark) {
${SYSTEM_SEL} {
${block(Object.entries(DARK))}
${block(legacy(LEGACY_DARK))}
}
}`;

  const styleEl = document.createElement('style');
  styleEl.id = 'ps-theme-tokens';
  styleEl.textContent = css;
  (document.head || document.documentElement).appendChild(styleEl);

  // ---------- Polices (FontFace + ArrayBuffer : pas bloqué par la CSP font-src) ----------
  [
    ['PS Inter', 'Inter-400', '400'], ['PS Inter', 'Inter-500', '500'], ['PS Inter', 'Inter-600', '600'],
    ['PS Inter Tight', 'InterTight-400', '400'], ['PS Inter Tight', 'InterTight-500', '500'], ['PS Inter Tight', 'InterTight-600', '600'],
    ['PS Radley', 'Radley-400', '400']
  ].forEach(([family, file, weight]) => {
    fetch(chrome.runtime.getURL(`assets/fonts/${file}.woff2`))
      .then((r) => r.arrayBuffer())
      .then((buf) => new FontFace(family, buf, { weight, display: 'swap' }).load())
      .then((face) => document.fonts.add(face))
      .catch(() => {});
  });

  // ---------- Logo PerfectServe à la place du logo Claude ----------
  const logos = {};
  Promise.all(['dark', 'light'].map((v) =>
    fetch(chrome.runtime.getURL(`assets/logo-${v}.svg`)).then((r) => r.text()).then((t) => { logos[v] = t; })
  )).then(() => tickSafely());

  // Le mot-symbole « Claude » n'est pas le même élément selon le mode (barre repliée,
  // barre dépliée, page d'accueil) : on le repère par son attribut OU par son texte.
  const WORDMARKS = '[data-cds="ProductLogo"], [data-app-wordmark]';
  const NOT_UI = '[data-testid="transcript-list"], .standard-markdown, .progressive-markdown, .ProseMirror, .psr, [data-testid="chat-header"]';

  function logoNode(inSidebar) {
    const logo = document.createElement('span');
    logo.className = 'ps-logo';
    logo.innerHTML = `<span class="ps-logo-ink">${logos.dark}</span><span class="ps-logo-paper">${logos.light}</span>`;
    if (!inSidebar) return logo;
    const brand = document.createElement('span');
    brand.className = 'ps-brand';
    brand.append(logo);
    brand.insertAdjacentHTML('beforeend', '<span class="ps-brand-sub">AI Workspace</span>');
    return brand;
  }

  function replaceWordmark(el) {
    el.setAttribute('data-ps-hidden', '');
    const parent = el.parentElement;
    if (parent && !parent.querySelector(':scope > .ps-logo, :scope > .ps-brand')) {
      el.after(logoNode(!!el.closest('[data-testid="sidebar"]')));
    }
  }

  // Rangée « logo + replier + rechercher » au-dessus du panneau (barre dépliée)
  function markTitlebar(el) {
    if (el.closest('[data-testid="sidebar"]')) return;
    let row = el.parentElement;
    for (let i = 0; row && i < 6; i++, row = row.parentElement) {
      if (!row.querySelector('button[data-cds="Button"]')) continue;
      const r = row.getBoundingClientRect();
      if (r.height && r.height < 90 && r.width < 520) row.setAttribute('data-ps-titlebar', '');
      return;
    }
  }

  function swapLogos() {
    if (!logos.dark) return;
    document.querySelectorAll(WORDMARKS).forEach((el) => {
      if (!el.closest('[data-ps-hidden]')) replaceWordmark(el);
    });
    document.querySelectorAll('.font-voice').forEach((el) => {
      if (el.closest('[data-ps-hidden]') || el.closest(NOT_UI) || el.textContent.trim() !== 'Claude') return;
      replaceWordmark(el);
    });
    const hits = document.evaluate("//body//*[not(*) and normalize-space(.)='Claude']", document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    for (let i = 0; i < hits.snapshotLength; i++) {
      const el = hits.snapshotItem(i);
      if (el.closest('[data-ps-hidden]') || el.closest(NOT_UI)) continue;
      const r = el.getBoundingClientRect();
      if (r.width && r.top < 120 && r.left < 360 && parseFloat(getComputedStyle(el).fontSize) >= 16) replaceWordmark(el);
    }
    document.querySelectorAll('[data-ps-hidden]').forEach(markTitlebar);
  }

  // ---------- Onglets « Chat / Code » en haut de la barre latérale ----------
  // Le composant peint ses propres fonds blancs : on le repère par ses libellés,
  // puis on identifie le rail et le curseur à partir de leurs couleurs réelles.
  const isPainted = (el) => {
    const bg = getComputedStyle(el).backgroundColor;
    const m = bg.match(/rgba?\(([^)]+)\)/);
    if (!m) return bg !== 'transparent' && bg !== 'none';
    const parts = m[1].split(/[\s,\/]+/).filter(Boolean);
    return parts.length < 4 || parseFloat(parts[3]) > 0.02;
  };
  const exact = (re) => (el) => el.childElementCount <= 3 && re.test(el.textContent.trim());

  let segMissAt = 0;
  function findSegmented() {
    const existing = document.querySelector('[data-ps-seg]');
    if (existing?.isConnected) return existing;
    if (performance.now() - segMissAt < 300) return null;
    segMissAt = performance.now();
    const scope = document.querySelector('[data-testid="sidebar"]')?.closest('aside') || document.querySelector('[data-testid="sidebar"]');
    if (!scope) return null;
    const nodes = [...scope.querySelectorAll('button, a, span, div, [role="tab"], [role="radio"]')];
    const chat = nodes.find(exact(/^chat$/i));
    const code = chat && nodes.find(exact(/^code$/i));
    if (!chat || !code) return null;
    let root = chat.parentElement;
    while (root && !root.contains(code)) root = root.parentElement;
    if (!root) return null;
    const r = root.getBoundingClientRect();
    if (!r.width || r.height > 72 || r.width > 420) return null;
    root.setAttribute('data-ps-seg', '');
    return root;
  }

  function styleSegmented() {
    const seg = findSegmented();
    if (!seg) return;
    const W = seg.getBoundingClientRect().width;
    seg.querySelectorAll('*:not([data-ps-seg-track]):not([data-ps-seg-thumb]):not([data-ps-seg-skip])').forEach((el) => {
      if (el.closest('[data-cds="Icon"]') || !isPainted(el)) return;
      const w = el.getBoundingClientRect().width;
      el.setAttribute(w >= W * 0.8 ? 'data-ps-seg-track' : w > 0 ? 'data-ps-seg-thumb' : 'data-ps-seg-skip', '');
    });
    // Onglet actif : attribut ARIA si présent, sinon celui qui se trouve sous le curseur
    const items = [...seg.querySelectorAll('button, a, [role="tab"], [role="radio"]')];
    if (!items.length) return;
    const aria = items.find((i) => i.matches('[aria-selected="true"], [aria-checked="true"], [aria-pressed="true"], [aria-current="page"], [data-state="active"], [data-state="on"]'));
    let on = aria;
    const thumb = seg.querySelector('[data-ps-seg-thumb]');
    if (!on && thumb) {
      const t = thumb.getBoundingClientRect(), cx = t.left + t.width / 2;
      on = items.find((i) => { const b = i.getBoundingClientRect(); return cx >= b.left && cx <= b.right; });
    }
    items.forEach((i) => i.toggleAttribute('data-ps-seg-on', i === on));
    keepSegmentedClear(seg);
  }

  // Le composant est décalé vers le haut par Claude : on mesure et on le redescend
  const SEG_GAP = 14;
  function keepSegmentedClear(seg) {
    const panel = document.querySelector('[data-testid="sidebar"]');
    if (!panel) return;
    const cur = parseFloat(seg.style.marginTop) || 0;
    const gap = seg.getBoundingClientRect().top - panel.getBoundingClientRect().top;
    if (Math.abs(gap - SEG_GAP) > 1) seg.style.setProperty('margin-top', `${cur + SEG_GAP - gap}px`, 'important');
  }

  // ---------- Filet de sécurité : aucun fond clair dans le panneau vert ----------
  // Tout élément (ou pseudo-élément) de la barre latérale peint en clair est repeint.
  const KEEP_LIGHT = '.df-leading-slot, .df-leading-slot *, [data-ps-seg-thumb], a[href="/new"], a[href="/new"] *, [data-cds="Avatar"], [data-cds="Avatar"] *, .ps-logo, .ps-logo *, .ps-brand, .ps-brand *, kbd, kbd *';
  function parseColor(c) {
    let m = c.match(/rgba?\(([^)]+)\)/);
    if (m) {
      const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
      return { r: p[0] / 255, g: p[1] / 255, b: p[2] / 255, a: p.length > 3 ? p[3] : 1 };
    }
    m = c.match(/color\(srgb\s+([^)]+)\)/);
    if (m) {
      const p = m[1].split(/[\s\/]+/).filter(Boolean).map(parseFloat);
      return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
    }
    return null;
  }
  const isLight = (c) => { const k = parseColor(c); return k && k.a > 0.25 && (0.2126 * k.r + 0.7152 * k.g + 0.0722 * k.b) > 0.7; };
  let lastScan = 0;
  function darkenSidebar() {
    const now = performance.now();
    if (now - lastScan < 800) return;
    lastScan = now;
    const panel = document.querySelector('[data-testid="sidebar"]');
    if (!panel) return;
    const scope = panel.closest('aside') || panel;
    scope.querySelectorAll('*').forEach((el) => {
      if (el.matches(KEEP_LIGHT) || el.closest('[data-ps-titlebar]')) return;
      if (!panel.contains(el) && !el.closest('[data-ps-seg]')) {
        // hors du panneau vert (barre de titre sur fond clair) : on ne touche pas
        const r = el.getBoundingClientRect(), pr = panel.getBoundingClientRect();
        if (r.bottom < pr.top || r.top > pr.bottom) return;
      }
      // marquage définitif : une fois repeint, l'élément ne paraît plus clair, il ne faut pas le démarquer
      const cs = getComputedStyle(el);
      if (!el.hasAttribute('data-ps-light') &&
          (isLight(cs.backgroundColor) || (/gradient/.test(cs.backgroundImage) && /255,\s*255,\s*255/.test(cs.backgroundImage)))) {
        el.setAttribute('data-ps-light', '');
      }
      if (!el.hasAttribute('data-ps-light-before') && isLight(getComputedStyle(el, '::before').backgroundColor)) el.setAttribute('data-ps-light-before', '');
      if (!el.hasAttribute('data-ps-light-after') && isLight(getComputedStyle(el, '::after').backgroundColor)) el.setAttribute('data-ps-light-after', '');
    });
  }

  // ---------- Page « nouvelle conversation » : logo PerfectServe au-dessus du message d'accueil ----------
  const isHome = () => document.documentElement.dataset.newPageLayout === 'home' || /^\/(new)?$/.test(location.pathname);
  function findGreeting() {
    const cands = [...document.querySelectorAll('h1, h2, .font-display, [class*="greeting" i]')].filter((el) => {
      if (el.closest('[data-testid="sidebar"], [data-testid="transcript-list"], .psr, .ps-home-logo')) return false;
      const t = el.textContent.trim();
      const r = el.getBoundingClientRect();
      return t.length > 1 && t.length < 90 && r.width > 0 && r.top > 40;
    });
    let best = null, size = 0;
    cands.forEach((el) => { const f = parseFloat(getComputedStyle(el).fontSize); if (f >= 22 && f > size) { best = el; size = f; } });
    return best;
  }
  function homeLogo() {
    if (!logos.dark || !isHome()) return;
    if (document.querySelector('.ps-home-logo')?.isConnected) return;
    const greet = findGreeting();
    if (!greet) return;
    // la rangée qui contient l'étincelle + le texte, si elle existe
    const row = greet.parentElement?.querySelector(':scope > svg[data-cds="Spark"], :scope > * svg[data-cds="Spark"]') ? greet.parentElement : greet;
    if (row.querySelector(':scope > .ps-home-logo')) return;
    document.querySelectorAll('.ps-home-logo').forEach((n) => n.remove());
    row.setAttribute('data-ps-greet', '');
    const logo = document.createElement('div');
    logo.className = 'ps-home-logo';
    logo.innerHTML = `<span class="ps-logo-ink">${logos.dark}</span><span class="ps-logo-paper">${logos.light}</span>`;
    row.appendChild(logo);
  }

  // ---------- Onglet : titre + favicon (symbole Signal) ----------
  let FAVICON = null;
  fetch(chrome.runtime.getURL('assets/mark.svg')).then((r) => r.text())
    .then((t) => { FAVICON = 'data:image/svg+xml,' + encodeURIComponent(t); tickSafely(); });
  function brandTab() {
    const t = document.title;
    if (t && t.includes('Claude')) document.title = t.replace(/Claude/g, 'PerfectServe AI');
    if (!FAVICON) return;
    // on ne supprime jamais les balises gérées par la page (React) : on change seulement leur adresse
    document.querySelectorAll('link[rel~="icon"]').forEach((l) => {
      if (l.getAttribute('href') !== FAVICON) { l.setAttribute('href', FAVICON); l.setAttribute('type', 'image/svg+xml'); }
    });
  }

  function syncDark() {
    const h = document.documentElement;
    const dark = h.dataset.mode === 'dark' || (h.dataset.mode === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    h.classList.toggle('ps-dark', dark);
  }

  // Chaque étape est isolée : une erreur dans l'une ne bloque jamais la page
  const safe = (fn) => { try { fn(); } catch (e) { console.warn('[PerfectServe]', e); } };
  function tick() {
    safe(swapLogos);
    safe(styleSegmented);
    safe(homeLogo);
    safe(darkenSidebar);
    safe(brandTab);
    safe(syncDark);
    if (document.head && styleEl.parentNode !== document.head) document.head.appendChild(styleEl);
  }

  // Aucune modification du DOM tant que claude.ai n'a pas fini de démarrer :
  // toucher la page pendant son initialisation (React) peut bloquer le chargement.
  let started = false;
  const tickSafely = () => { if (started) tick(); };
  let queued = false;
  function start() {
    if (started) return;
    started = true;
    tick();
    new MutationObserver(() => {
      if (queued) return;
      queued = true;
      setTimeout(() => { queued = false; tick(); }, 250);
    }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-mode'] });
    setInterval(() => safe(darkenSidebar), 2000);
    // Le sélecteur Chat / Code se recale tout seul, sans attendre un survol
    setInterval(() => { safe(styleSegmented); safe(homeLogo); }, 500);
    window.addEventListener('resize', () => safe(styleSegmented));
    let watchedPanel = null;
    const ro = new ResizeObserver(() => safe(styleSegmented));
    setInterval(() => {
      const panel = document.querySelector('[data-testid="sidebar"]');
      if (panel && panel !== watchedPanel) { ro.disconnect(); ro.observe(panel); watchedPanel = panel; }
    }, 500);
  }
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => safe(syncDark));
  const startLater = () => setTimeout(start, 1200);
  if (document.readyState === 'complete') startLater();
  else window.addEventListener('load', startLater, { once: true });
})();
