// Usage insights: records each sent prompt, ANONYMIZED locally, so the PerfectServe dashboard can
// surface recurring themes worth automating. Users are informed (company policy + a one-time notice).
// No delay for the user: capture happens at send time, the network call is done by the service
// worker in batches.
(() => {
  const EDITOR = '.ProseMirror[contenteditable="true"], div[contenteditable="true"]';
  const SEND_BTN = '[data-testid="chat-input-send"], button[aria-label^="Envoyer"], button[aria-label^="Send"], .rounded-composer button[type="submit"], fieldset button[type="submit"]';

  let editor = null, last = '', lastAt = 0;
  const getEditor = () => (editor?.isConnected && editor) ||
    document.querySelector('[data-testid="chat-input"]') || document.querySelector(EDITOR);
  const modelName = () => {
    const b = document.querySelector('[data-testid="model-selector-dropdown"]');
    return ((b?.getAttribute('aria-label') || b?.textContent || '').match(/(Fable|Mythos|Opus|Sonnet|Haiku)\s*[\d.]*/i) || [''])[0].trim();
  };

  function capture() {
    const raw = (getEditor()?.innerText || '').trim();
    if (raw.length < 3) return;
    const now = Date.now();
    if (raw === last && now - lastAt < 4000) return;   // keydown + click of the same send
    last = raw; lastAt = now;
    setTimeout(() => {                                   // out of Claude's send path
      try {
        const anon = globalThis.PSPrivacy ? globalThis.PSPrivacy.anonymize(raw) : { text: raw, items: [] };
        chrome.runtime.sendMessage({
          type: 'ps-log',
          entry: {
            text: anon.text.slice(0, 4000),
            chars: raw.length,
            sensitive: anon.items.map((i) => i.type),
            model: modelName(),
            at: new Date(now).toISOString()
          }
        }).catch(() => {});
      } catch {}
    }, 0);
  }

  // registered after privacy.js: a send blocked by the privacy shield never reaches this point
  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
    const ed = e.target?.closest?.(EDITOR);
    if (ed) { editor = ed; capture(); }
  }, true);
  window.addEventListener('click', (e) => { if (e.target?.closest?.(SEND_BTN)) capture(); }, true);

  // ---------- one-time notice ----------
  const NOTICE_KEY = 'psInsightsNoticeSeen';
  function notice() {
    const n = document.createElement('div');
    n.className = 'psn';
    n.setAttribute('role', 'status');
    n.innerHTML = `<span class="psn-ic"><svg viewBox="0 0 24 24"><path d="M12 3.5 19 6v5.5c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6z"/><path d="m9 12 2.2 2.2L15.5 10"/></svg></span>
      <span class="psn-t"><b>Usage insights are on.</b> Your prompts are anonymized on this device, then analyzed to find tasks worth automating.</span>
      <button type="button" class="psn-ok">Got it</button>`;
    n.querySelector('.psn-ok').addEventListener('click', () => {
      n.classList.remove('psn-on');
      chrome.storage.local.set({ [NOTICE_KEY]: true });
      setTimeout(() => n.remove(), 400);
    });
    document.body.appendChild(n);
    requestAnimationFrame(() => n.classList.add('psn-on'));
  }
  const start = () => chrome.storage.local.get(NOTICE_KEY).then((r) => { if (!r[NOTICE_KEY]) setTimeout(notice, 2500); }).catch(() => {});
  if (document.readyState === 'complete') start(); else window.addEventListener('load', start);
})();
