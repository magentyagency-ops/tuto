importScripts('config.js');

// ----- Usage insights: anonymized prompts queued locally, sent in batches (never blocks the page) -----
const QUEUE_KEY = 'psInsightsQueue', ID_KEY = 'psInstallId', MAX_QUEUE = 500, BATCH = 50;
let flushing = false, flushTimer;

async function installId() {
  const r = await chrome.storage.local.get(ID_KEY);
  if (r[ID_KEY]) return r[ID_KEY];
  const id = 'inst-' + crypto.randomUUID();      // random, not linked to the person's name
  await chrome.storage.local.set({ [ID_KEY]: id });
  return id;
}

async function enqueue(entry) {
  const r = await chrome.storage.local.get(QUEUE_KEY);
  const q = (r[QUEUE_KEY] || []).concat(entry).slice(-MAX_QUEUE);
  await chrome.storage.local.set({ [QUEUE_KEY]: q });
  clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 5000);          // small grouping delay
}

async function flush() {
  if (flushing || !self.INSIGHTS_URL) return;
  flushing = true;
  try {
    const q = (await chrome.storage.local.get(QUEUE_KEY))[QUEUE_KEY] || [];
    if (!q.length) return;
    const batch = q.slice(0, BATCH);
    const res = await fetch(self.INSIGHTS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-PS-Token': self.INSIGHTS_TOKEN || '' },
      body: JSON.stringify({ user: await installId(), items: batch })
    });
    if (!res.ok) return;                         // kept in the queue, retried later
    const rest = ((await chrome.storage.local.get(QUEUE_KEY))[QUEUE_KEY] || []).slice(batch.length);
    await chrome.storage.local.set({ [QUEUE_KEY]: rest });
    if (rest.length) setTimeout(flush, 1000);
  } catch { /* offline or server down: retried by the alarm */ } finally { flushing = false; }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'ps-log' && msg.entry) enqueue(msg.entry);
});
chrome.alarms.create('ps-insights-flush', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'ps-insights-flush') flush(); });

// AI advisor: the routing call goes through the PerfectServe server, which holds the OpenAI key
// (a key shipped inside the extension gets revoked as soon as the archive is published).
async function callOpenAI(prompt) {
  const res = await fetch(self.INSIGHTS_URL.replace(/\/api\/ingest$/, '/api/route'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-PS-Token': self.INSIGHTS_TOKEN || '' },
    body: JSON.stringify({ prompt: prompt.slice(0, 8000) })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
  return data;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== 'route') return;
  const t0 = performance.now();
  callOpenAI(msg.prompt)
    .then((r) => sendResponse({ ok: true, ...r, ms: Math.round(performance.now() - t0) }))
    .catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
  return true;
});

// ----- Capture de diagnostic (⌥⇧D) : structure DOM + capture d'écran dans Téléchargements -----
async function snapshot(tab) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  let png = null;
  try { png = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }); } catch (e) { console.warn('capture', e); }
  const json = await chrome.tabs.sendMessage(tab.id, { type: 'ps-collect' });
  await chrome.downloads.download({
    url: 'data:application/json;charset=utf-8,' + encodeURIComponent(json),
    filename: `claude-snapshot/claude-dom-${stamp}.json`
  });
  if (png) await chrome.downloads.download({ url: png, filename: `claude-snapshot/claude-screen-${stamp}.png` });
  return { ok: true, screenshot: !!png };
}

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'ps-snapshot') return;
  tab = tab || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (tab?.url?.startsWith('https://claude.ai/')) snapshot(tab).catch((e) => console.error(e));
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'ps-snapshot' || !sender.tab) return;
  snapshot(sender.tab).then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e) }));
  return true;
});
