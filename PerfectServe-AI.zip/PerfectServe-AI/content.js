// Conseiller IA discret : analyse le prompt en arrière-plan pendant la frappe et,
// seulement si un autre assistant est nettement plus adapté, affiche une petite suggestion.
// L'envoi vers Claude n'est jamais bloqué ni retardé.
(() => {
  const EDITOR_SELECTOR = '.ProseMirror[contenteditable="true"], div[contenteditable="true"]';
  const PAUSE_MS = 700;        // délai après la dernière frappe avant d'analyser
  const MIN_CHARS = 12;        // trop court : pas d'analyse
  const MIN_CONFIDENCE = 65;   // en dessous : on ne dérange pas

  const GLYPH = {
    chatgpt: '<path d="M5 6.5h14v9.5a1.5 1.5 0 0 1-1.5 1.5H10l-4 3v-3h-.5A1.5 1.5 0 0 1 4 16V8a1.5 1.5 0 0 1 1-1.5z" fill="none" stroke="#fff" stroke-width="2.2" stroke-linejoin="round"/>',
    gemini: '<path d="M12 3c.6 4.7 3.5 7.6 9 9-5.5 1.4-8.4 4.3-9 9-.6-4.7-3.5-7.6-9-9 5.5-1.4 8.4-4.3 9-9z" fill="#fff"/>',
    perplexity: '<circle cx="11" cy="11" r="6" fill="none" stroke="#fff" stroke-width="2.4"/><path d="m19.5 19.5-4-4" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>'
  };
  const AI = {
    chatgpt: { name: 'ChatGPT', bg: '#10a37f', url: (q) => `https://chatgpt.com/?q=${encodeURIComponent(q)}` },
    gemini: { name: 'Gemini', bg: 'linear-gradient(135deg,#4285f4,#9b72cb 55%,#d96570)', url: () => 'https://gemini.google.com/app' },
    perplexity: { name: 'Perplexity', bg: '#20808d', url: (q) => `https://www.perplexity.ai/search?q=${encodeURIComponent(q)}` }
  };

  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  // la zone où l'on tape réellement (et pas la première zone éditable trouvée dans la page)
  let activeEditor = null;
  const getEditor = () => (activeEditor?.isConnected && activeEditor) ||
    document.querySelector('[data-testid="chat-input"]') ||
    document.querySelector('.rounded-composer .ProseMirror') ||
    document.querySelector(EDITOR_SELECTOR);
  const getPrompt = () => (getEditor()?.innerText || '').trim();
  // État de diagnostic, lu par la capture ⌥⇧D (debug.js partage le même contexte)
  const diag = globalThis.__psAdvisor = { loaded: new Date().toISOString(), inputs: 0, typed: 0, analyses: [], errors: [] };
  const log = (...a) => console.debug('[PerfectServe · conseiller]', ...a);

  // ---------- Suggestion ----------
  let hint, timer, raf, current = null, dismissed = null;
  const cache = new Map();

  function ensureHint() {
    if (hint?.isConnected) return;
    hint = document.createElement('div');
    hint.className = 'psh';
    hint.setAttribute('role', 'status');
    hint.addEventListener('click', (e) => {
      const a = e.target.closest('[data-a]')?.dataset.a;
      if (a === 'open') openTarget();
      if (a === 'close') { dismissed = current?.target || null; hide(); }
    });
    document.body.appendChild(hint);
  }

  function place() {
    const composer = document.querySelector('.rounded-composer') || getEditor();
    const r = composer?.getBoundingClientRect();
    if (!r?.width) return;
    hint.style.left = `${r.left + 14}px`;
    hint.style.bottom = `${window.innerHeight - r.top + 8}px`;
    hint.style.maxWidth = `${Math.max(240, r.width - 28)}px`;
  }
  const follow = () => { if (!hint?.classList.contains('psh-on')) return; place(); raf = requestAnimationFrame(follow); };

  let stickyTimer;
  function show(res, prompt, afterSend = false) {
    ensureHint();
    const t = AI[res.target];
    current = { target: res.target, prompt, sticky: afterSend };
    clearTimeout(stickyTimer);
    if (afterSend) stickyTimer = setTimeout(() => { if (current?.sticky) hide(); }, 12000);
    hint.title = res.reason || '';
    hint.innerHTML = `
      <span class="psh-tile" style="background:${t.bg}"><svg viewBox="0 0 24 24" aria-hidden="true">${GLYPH[res.target]}</svg></span>
      <span class="psh-text">${afterSend ? 'For this request, ' : ''}<b>${t.name}</b> ${afterSend ? 'might have been a better fit' : 'might be a better fit'}<span class="psh-why"> · ${esc(res.reason)}</span></span>
      <button type="button" class="psh-open" data-a="open">Open<svg viewBox="0 0 24 24"><path d="M7 17 17 7M9 7h8v8"/></svg></button>
      <button type="button" class="psh-x" data-a="close" aria-label="Dismiss"><svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg></button>`;
    place();
    hint.classList.add('psh-on');
    cancelAnimationFrame(raf); raf = requestAnimationFrame(follow);
  }

  function hide() {
    if (!hint) return;
    hint.classList.remove('psh-on');
    cancelAnimationFrame(raf);
    current = null;
  }

  async function openTarget() {
    if (!current) return;
    const { target } = current;
    const prompt = globalThis.PSPrivacy ? globalThis.PSPrivacy.anonymize(current.prompt).text : current.prompt;
    try { await navigator.clipboard.writeText(prompt); } catch {}
    window.open(AI[target].url(prompt), '_blank');
    hint.querySelector('.psh-text').innerHTML = `Opened in <b>${AI[target].name}</b> — prompt copied`;
    hint.querySelector('.psh-open')?.remove();
    setTimeout(hide, 1800);
  }

  // ---------- Analyse silencieuse ----------
  async function analyse(prompt, afterSend = false) {
    if (!cache.has(prompt)) {
      // le texte part toujours anonymisé : aucune donnée sensible n'est transmise à OpenAI
      const safePrompt = globalThis.PSPrivacy ? globalThis.PSPrivacy.anonymize(prompt).text : prompt;
      cache.set(prompt, chrome.runtime.sendMessage({ type: 'route', prompt: safePrompt }).catch((e) => { diag.errors.push(String(e?.message || e)); return null; }));
      if (cache.size > 30) cache.delete(cache.keys().next().value);
    }
    const res = await cache.get(prompt);
    log(prompt.slice(0, 60), '→', res);
    diag.analyses.push({ len: prompt.length, res, same: getPrompt() === prompt, at: new Date().toISOString() });
    if (diag.analyses.length > 10) diag.analyses.shift();
    if (!res) log('pas de réponse du service : recharge l’extension puis ouvre un nouvel onglet claude.ai');
    if (!afterSend && getPrompt() !== prompt) return;   // le texte a changé entre-temps : réponse périmée
    const relevant = res?.ok && AI[res.target] && (res.confidence ?? 0) >= MIN_CONFIDENCE;
    if (!relevant || res.target === dismissed) { if (!current?.sticky || afterSend) hide(); return; }
    if (globalThis.PSPrivacy?.busy()) return;          // l'alerte de confidentialité reste prioritaire
    show(res, prompt, afterSend);
  }

  document.addEventListener('input', (e) => {
    const ed = e.target?.closest?.(EDITOR_SELECTOR);
    if (!ed) return;
    activeEditor = ed;
    diag.inputs++;
    clearTimeout(timer);
    const prompt = getPrompt();
    if (prompt.length < MIN_CHARS) { dismissed = null; return hide(); }
    // la suggestion affichée ne correspond plus au texte : on la retire en douceur
    if (current && current.prompt !== prompt) hide();
    timer = setTimeout(() => analyse(getPrompt()), PAUSE_MS);
  }, true);

  document.addEventListener('keyup', (e) => {
    const ed = e.target?.closest?.(EDITOR_SELECTOR);
    if (ed && e.key.length === 1) ed.dispatchEvent(new CustomEvent('ps-typed', { bubbles: true }));
  }, true);
  document.addEventListener('ps-typed', (e) => {
    activeEditor = e.target.closest(EDITOR_SELECTOR) || activeEditor;
    diag.typed++;
    clearTimeout(timer);
    const prompt = getPrompt();
    if (prompt.length < MIN_CHARS) return hide();
    timer = setTimeout(() => analyse(getPrompt()), PAUSE_MS);
  }, true);

  const SEND_BTN = '[data-testid="chat-input-send"], button[aria-label="Envoyer le message"], button[aria-label="Send message"], button[aria-label="Send Message"]';
  let lastSent = '';
  function onSend() {
    const prompt = getPrompt();
    if (prompt.length < MIN_CHARS || prompt === lastSent) return;
    lastSent = prompt;
    clearTimeout(timer);
    diag.sends = (diag.sends || 0) + 1;
    dismissed = null;
    analyse(prompt, true);
  }
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.target?.closest?.(EDITOR_SELECTOR)) {
      activeEditor = e.target.closest(EDITOR_SELECTOR);
      onSend();
    }
  }, true);
  window.addEventListener('pointerdown', (e) => { if (e.target?.closest?.(SEND_BTN)) onSend(); }, true);

  // Message envoyé (zone vidée) : on efface toute trace
  new MutationObserver(() => {
    if (current && !current.sticky && !getPrompt()) { hide(); dismissed = null; }
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && current) { dismissed = current.target; hide(); } }, true);
  window.addEventListener('resize', () => current && place());
})();
