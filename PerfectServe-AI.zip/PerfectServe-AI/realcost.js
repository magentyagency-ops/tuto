// Real cost per exchange, read from the Enterprise usage meter ("$0.65 of $50.00 spent").
// No setup: a hidden copy of Settings › Usage is loaded in the background of the claude.ai tab.
// Spend is read just before sending and again once the reply is finished; the difference is what
// the exchange really cost (context, thinking, tools, files included).
// If the claude.ai API call behind the meter is identified, it is read directly (no hidden page).
(() => {
  const SOURCE_KEY = 'psUsageSource', COSTS_KEY = 'psRealCosts', MAX_COSTS = 2000;
  const USAGE_URL = '/settings/usage';
  const HINT = /usage|spend|cost|billing|limit|credit|budget/i;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const TOP = window.top === window;
  const PROBE = 'ps-usage-probe';

  // step-by-step diagnostic log kept in the extension's storage (last 150 events)
  const LOG_KEY = 'psRealCostLog';
  let logQ = Promise.resolve();
  function dbg(ev, data) {
    const e = { t: new Date().toISOString().slice(11, 19), f: TOP ? 'tab' : 'frame', ev, ...(data || {}) };
    logQ = logQ.then(() => chrome.storage.local.get(LOG_KEY))
      .then((r) => chrome.storage.local.set({ [LOG_KEY]: (r[LOG_KEY] || []).concat(e).slice(-150) })).catch(() => {});
  }

  // API calls seen by this frame (an observer is not limited by the 250-entry timing buffer)
  const apiSeen = new Set();
  try {
    new PerformanceObserver((l) => l.getEntries().forEach((e) => {
      if (e.name.startsWith(location.origin + '/api/')) apiSeen.add(e.name);
    })).observe({ type: 'resource', buffered: true });
  } catch {}

  let source = null;
  chrome.storage.local.get(SOURCE_KEY).then((r) => { source = r[SOURCE_KEY] || null; }).catch(() => {});
  chrome.storage.onChanged.addListener((ch) => { if (ch[SOURCE_KEY]) source = ch[SOURCE_KEY].newValue || null; });

  // ---------- reading amounts ----------
  // "0,65 $US", "$1,234.56", "1 234,56" → number
  function num(s) {
    s = String(s).replace(/[\s  ]/g, '').replace(/[^\d.,-]/g, '');
    const dec = Math.max(s.lastIndexOf(','), s.lastIndexOf('.'));
    if (dec < 0) return parseFloat(s);
    const both = s.includes(',') && s.includes('.');
    if (both || s.length - dec - 1 !== 3) return parseFloat(s.slice(0, dec).replace(/[.,]/g, '') + '.' + s.slice(dec + 1));
    return parseFloat(s.replace(/[.,]/g, ''));            // "1,234" = thousands
  }

  const METER = /(\d[\d\s  .,]*)\s*(?:\$\s*US|US\s*\$|\$|USD|€|EUR)?\s*(?:sur|of|\/)\s*(?:\$\s*)?(\d[\d\s  .,]*)/i;
  function readMeter(anywhere) {
    const root = document.querySelector('[data-perf-screen="usage"]') || (anywhere && document.body);
    if (!root) return null;
    for (const el of root.querySelectorAll('div, span, p')) {
      if (el.children.length) continue;
      const t = el.textContent || '';
      if (!/dépens|spent|used|utilis/i.test(t)) continue;
      const m = t.match(METER);
      if (m) return { spent: num(m[1]), limit: num(m[2]) };
    }
    return null;
  }

  async function getJSON(url) {
    const r = await fetch(url, { credentials: 'include', cache: 'no-store' });
    if (!r.ok || !(r.headers.get('content-type') || '').includes('json')) return null;
    return r.json();
  }

  async function apiSpend() {
    if (!source) return null;
    try {
      const d = await getJSON(source.url);
      let v = source.path.reduce((o, k) => (o == null ? o : o[k]), d);
      v = typeof v === 'string' ? parseFloat(v) : v;
      return Number.isFinite(v) ? v * source.scale : null;
    } catch { return null; }
  }

  // ---------- identify the API call behind the meter (same value as on screen) ----------
  function leaves(o, path, out, parent) {
    if (o && typeof o === 'object') {
      for (const k of Object.keys(o)) leaves(o[k], path.concat(Array.isArray(o) ? Number(k) : k), out, o);
    } else {
      const v = typeof o === 'string' && /^-?\d+(\.\d+)?$/.test(o) ? parseFloat(o) : o;
      if (typeof v === 'number' && Number.isFinite(v)) out.push({ path, v, parent });
    }
    return out;
  }

  async function calibrate(meter) {
    const urls = [...apiSeen].filter((u) => HINT.test(u)).reverse().slice(0, 25);
    let best = null;
    for (const url of urls) {
      let data;
      try { data = await getJSON(url); } catch { continue; }
      if (!data) continue;
      for (const { path, v, parent } of leaves(data, [], [])) {
        for (const scale of [1, 0.01, 0.001, 1e-6]) {
          if (Math.abs(v * scale - meter.spent) > 0.0051) continue;
          const sib = parent && typeof parent === 'object' ? Object.values(parent) : [];
          const hasLimit = sib.some((x) => Math.abs(parseFloat(x) * scale - meter.limit) < 0.0051);
          const key = String(path[path.length - 1]);
          const score = (hasLimit ? 4 : 0) + (/spen|used|usage|cost|amount|total/i.test(key) ? 2 : 0)
            + (/day|daily|date|week/i.test(path.join('.')) ? -3 : 0) + (/\d{4}-\d{2}-\d{2}/.test(url) ? -1 : 0);
          if (!best || score > best.score) best = { url, path, scale, score };
        }
      }
    }
    dbg('calibrate', { seen: apiSeen.size, candidates: urls.map((u) => u.replace(location.origin, '')), best });
    if (!best || best.score < 2) return false;            // a lone matching number is not enough
    source = { url: best.url, path: best.path, scale: best.scale, at: new Date().toISOString() };
    await chrome.storage.local.set({ [SOURCE_KEY]: source });
    return true;
  }

  // ======================= hidden Usage page (iframe) =======================
  if (!TOP) {
    if (window.name !== PROBE) return;
    dbg('frame-start', { path: location.pathname });
    setTimeout(() => dbg('frame-state', {
      path: location.pathname,
      usageScreen: !!document.querySelector('[data-perf-screen="usage"]'),
      meter: readMeter(true),
      amounts: ((document.body?.innerText || '').match(/[^\n]*\$[^\n]*/g) || []).slice(0, 6)
    }), 8000);
    let calibrated = false;
    const refreshBtn = () => document.querySelector('button[aria-label="Actualiser"], button[aria-label="Refresh"], button[aria-label*="efresh" i]');
    window.addEventListener('message', async (e) => {
      if (e.origin !== location.origin || !e.data?.psMeterRead) return;
      const btn = refreshBtn();
      if (btn) { btn.click(); await sleep(1200); }
      const meter = readMeter(true);
      dbg('frame-read', { meter, refresh: !!btn, path: location.pathname });
      window.top.postMessage({ psMeterReply: e.data.psMeterRead, meter }, location.origin);
      if (meter && meter.spent > 0 && !calibrated) {
        calibrated = true;
        const v = await apiSpend();
        if (v == null || Math.abs(v - meter.spent) > 0.0151) calibrate(meter).catch(() => {});
      }
    });
    return;
  }

  // ======================= claude.ai tab =======================
  let costs = {};
  const pending = new Set();
  chrome.storage.local.get(COSTS_KEY).then((r) => { costs = r[COSTS_KEY] || {}; }).catch(() => {});
  chrome.storage.onChanged.addListener((ch) => { if (ch[COSTS_KEY]) costs = ch[COSTS_KEY].newValue || {}; });

  globalThis.PSRealCost = {
    get: (key) => key && costs[key],
    pending: (key) => pending.has(key),
    apiSeen: () => [...apiSeen].map((u) => u.replace(location.origin, '')).slice(-60)
  };

  dbg('tab-start', { version: chrome.runtime.getManifest().version, path: location.pathname });
  let frame = null, frameUsedAt = 0;
  function ensureFrame() {
    frameUsedAt = Date.now();
    if (frame?.isConnected) return;
    frame = document.createElement('iframe');
    frame.name = PROBE;
    frame.src = USAGE_URL;
    frame.addEventListener('load', () => dbg('frame-onload'));
    dbg('frame-create');
    frame.tabIndex = -1;
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;left:-5000px;top:0;width:1100px;height:800px;opacity:0;pointer-events:none;border:0;';
    document.documentElement.appendChild(frame);
  }
  // free the hidden page after 10 idle minutes
  setInterval(() => { if (frame && Date.now() - frameUsedAt > 10 * 60e3) { frame.remove(); frame = null; } }, 60e3);

  function frameRead(timeout = 15000) {
    ensureFrame();
    const id = Math.random().toString(36).slice(2);
    return new Promise((resolve) => {
      const t0 = Date.now();
      const onMsg = (e) => {
        if (e.origin !== location.origin || e.data?.psMeterReply !== id || !e.data.meter) return;
        done(e.data.meter.spent);
      };
      const ask = () => {
        if (Date.now() - t0 > timeout) return done(null);
        try { frame?.contentWindow?.postMessage({ psMeterRead: id }, location.origin); } catch {}
      };
      const tick = setInterval(ask, 1500);
      ask();
      function done(v) { dbg('read', { v, ms: Date.now() - t0 }); clearInterval(tick); window.removeEventListener('message', onMsg); resolve(v); }
      window.addEventListener('message', onMsg);
    });
  }

  async function readSpend() {
    const v = await apiSpend();
    if (v != null) return v;
    return frameRead();
  }

  let last = null, warming = false;                     // { v, at } read while typing
  async function warm() {
    if (warming || (last && Date.now() - last.at < 4000)) return;
    warming = true;
    const at = Date.now(), v = await readSpend();
    if (v != null) last = { v, at };
    warming = false;
  }

  // ---------- measurement ----------
  const EDITOR = '.ProseMirror[contenteditable="true"], div[contenteditable="true"]';
  const SEND_BTN = '[data-testid="chat-input-send"], button[aria-label^="Envoyer"], button[aria-label^="Send"], fieldset button[type="submit"]';
  const lastAssistant = () => [...document.querySelectorAll('[data-testid="assistant-message"]')].pop();
  const round = (v) => Math.round(v * 1e6) / 1e6;
  let job = null, lastSend = 0;

  function save() {
    const keys = Object.keys(costs);
    if (keys.length > MAX_COSTS) keys.sort((a, b) => (costs[a].at || '').localeCompare(costs[b].at || '')).slice(0, keys.length - MAX_COSTS).forEach((k) => delete costs[k]);
    chrome.storage.local.set({ [COSTS_KEY]: costs }).catch(() => {});
  }

  function finish(j, after) {
    if (j.done) return;
    j.done = true;
    dbg('finish', { key: j.turnKey, before: j.before, after });
    pending.delete(j.seen);
    if (j.turnKey && after != null) {
      costs[j.turnKey] = { v: Math.max(0, round(after - j.before)), at: new Date().toISOString() };
      save();
    }
    if (job === j) job = null;
  }

  async function poll(j) {
    for (let i = 0; i < 30 && !j.done; i++) {             // up to ~2–3 min after the reply
      await sleep(3000);
      const v = await readSpend();
      if (v != null && v > j.before + 1e-9) {
        await sleep(4000);                                 // let follow-up charges land (e.g. chat title)
        const v2 = await readSpend();
        return finish(j, Math.max(v, v2 ?? v));
      }
    }
    finish(j, j.before);                                   // meter did not move: under its precision
  }

  async function onSend() {
    if (Date.now() - lastSend < 1500) return;
    const ed = document.querySelector('[data-testid="chat-input"]') || document.querySelector(EDITOR);
    if (!(ed?.innerText || '').trim()) return;
    lastSend = Date.now();
    const prevKey = lastAssistant()?.dataset.turnKey || null, path = location.pathname, sentAt = Date.now();
    const before = last && sentAt - last.at < 20000 && !job ? last.v : await readSpend();
    last = null;
    dbg('send', { before, api: !!source });
    if (job) finish(job, job.turnKey ? before : null);    // previous exchange ends where this one starts
    job = before == null ? null : { before, prevKey, path, sentAt };
  }

  function watch() {
    if (!job || job.turnKey) return;
    if ((job.path !== location.pathname && !job.path.startsWith('/new')) || Date.now() - job.sentAt > 10 * 60e3) {
      pending.delete(job.seen); job = null; return;
    }
    const a = lastAssistant();
    const key = a?.dataset.turnKey;
    if (!key || key === job.prevKey) return;
    pending.add(job.seen = key);
    if (a.dataset.isStreaming === 'false') { job.turnKey = key; dbg('reply-done', { key }); poll(job); }
  }

  // warm the hidden Usage page as soon as the user starts typing, so "before" is ready at send time
  window.addEventListener('focusin', (e) => { if (e.target?.closest?.(EDITOR)) { ensureFrame(); warm(); } }, true);
  // registered after privacy.js: a send blocked by the privacy shield never reaches this point
  window.addEventListener('keydown', (e) => {
    if (!e.target?.closest?.(EDITOR)) return;
    ensureFrame();
    if (e.key !== 'Enter') warm();
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) onSend();
  }, true);
  window.addEventListener('click', (e) => { if (e.target?.closest?.(SEND_BTN)) onSend(); }, true);
  setInterval(() => { try { watch(); } catch {} }, 1000);
})();
