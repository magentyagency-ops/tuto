// Capture de la structure réelle de claude.ai (⌥⇧D) pour ajuster le thème.
// Les textes longs sont tronqués : on garde la structure, pas le contenu des conversations.
(() => {
  const MAX_NODES = 6000;
  const KEEP_ATTR = /^(id|role|type|href|name|placeholder|contenteditable|tabindex|aria-.*|data-.*)$/;

  function skeleton(root) {
    let count = 0;
    const walk = (el, depth) => {
      if (count++ > MAX_NODES || depth > 40) return '…';
      const node = { t: el.tagName.toLowerCase() };
      if (typeof el.className === 'string' && el.className) node.c = el.className;
      else if (el.className?.baseVal) node.c = el.className.baseVal;
      const attrs = {};
      for (const a of el.attributes) if (KEEP_ATTR.test(a.name)) attrs[a.name] = a.value.slice(0, 80);
      if (Object.keys(attrs).length) node.a = attrs;
      const ownText = [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent.trim()).join(' ').trim();
      if (ownText) node.x = ownText.length > 30 ? ownText.slice(0, 30) + `…(${ownText.length})` : ownText;
      if (node.t === 'svg' || node.t === 'style' || node.t === 'script') return node;
      const kids = [...el.children].map((c) => walk(c, depth + 1));
      if (kids.length) node.k = kids;
      return node;
    };
    return walk(root, 0);
  }

  const STYLE_PROPS = ['display', 'position', 'background-color', 'background-image', 'color', 'border', 'border-radius',
    'box-shadow', 'font-family', 'font-size', 'font-weight', 'padding', 'margin', 'width', 'max-width', 'height'];
  function styleOf(el) {
    if (!el) return null;
    const cs = getComputedStyle(el);
    const s = { tag: el.tagName.toLowerCase(), cls: (el.className?.baseVal ?? el.className) || '' };
    STYLE_PROPS.forEach((p) => { s[p] = cs.getPropertyValue(p); });
    return s;
  }
  const chain = (el, n = 10) => {
    const out = [];
    for (let i = 0; el && i < n; i++, el = el.parentElement) out.push(styleOf(el));
    return out;
  };

  function themeRules() {
    const rules = [];
    for (const sheet of document.styleSheets) {
      let list;
      try { list = sheet.cssRules; } catch { rules.push({ sheet: sheet.href, error: 'cross-origin' }); continue; }
      const visit = (rs, media) => {
        for (const r of rs) {
          if (r.cssRules && !r.selectorText) { visit(r.cssRules, r.conditionText || r.media?.mediaText || media); continue; }
          if (!r.selectorText || !r.style) continue;
          const hasVars = [...r.style].some((p) => p.startsWith('--'));
          const interesting = hasVars && /:root|html|\.dark|data-theme|data-mode|body/.test(r.selectorText);
          const fontCls = /\.font-/.test(r.selectorText) && r.style.fontFamily;
          if (interesting || fontCls) rules.push({ media, sel: r.selectorText, css: r.style.cssText.slice(0, 6000) });
        }
      };
      visit(list, null);
    }
    return rules;
  }

  function collect() {
    const h = document.documentElement;
    const cs = getComputedStyle(h);
    const vars = {};
    for (const p of cs) if (p.startsWith('--') && !p.startsWith('--ps-') && !p.startsWith('--tw-')) vars[p] = cs.getPropertyValue(p).trim();

    const editor = document.querySelector('.ProseMirror, [contenteditable="true"]');
    const send = document.querySelector('button[aria-label*="Send" i], button[aria-label*="Envoyer" i]');
    const userMsg = document.querySelector('[data-testid="user-message"]');
    const reply = document.querySelector('.font-claude-response, .font-claude-message, [data-is-streaming]');

    return {
      when: new Date().toISOString(),
      url: location.pathname,
      viewport: [innerWidth, innerHeight],
      html: [...h.attributes].map((a) => `${a.name}="${a.value}"`),
      body: document.body.className,
      vars,
      themeRules: themeRules(),
      chains: {
        editor: chain(editor, 12),
        send: chain(send, 6),
        userMessage: chain(userMsg, 8),
        reply: chain(reply, 8),
        nav: chain(document.querySelector('nav'), 4),
        h1: chain(document.querySelector('h1'), 4)
      },
      advisor: (() => {
        const h = document.querySelector('.psh');
        const ed = document.querySelector('[data-testid="chat-input"]') || document.querySelector('.ProseMirror');
        return {
          state: globalThis.__psAdvisor || 'content.js non chargé',
          editors: [...document.querySelectorAll('[contenteditable="true"]')].map((e) => ({ cls: String(e.className).slice(0, 80), tid: e.dataset.testid || '', len: e.innerText.length })),
          composer: !!document.querySelector('.rounded-composer'),
          editorTextLen: ed?.innerText.length,
          hint: h ? { cls: h.className, rect: h.getBoundingClientRect().toJSON(), opacity: getComputedStyle(h).opacity, display: getComputedStyle(h).display } : null
        };
      })(),
      dom: skeleton(document.body)
    };
  }

  function downloadLocal(data) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    a.download = `claude-dom-${Date.now()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type === 'ps-collect') { reply(JSON.stringify(collect())); }
  });

  // Repli si le raccourci de l'extension n'est pas actif : ⌥⇧D télécharge seulement la structure
  window.addEventListener('keydown', (e) => {
    if (e.code !== 'KeyD' || !e.altKey || !e.shiftKey) return;
    e.preventDefault();
    chrome.runtime.sendMessage({ type: 'ps-snapshot' }).then((r) => {
      if (!r?.ok) downloadLocal(collect());
    }).catch(() => downloadLocal(collect()));
  }, true);
})();
